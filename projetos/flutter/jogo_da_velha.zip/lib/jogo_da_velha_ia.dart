

import 'dart:convert';

import 'package:google_generative_ai/google_generative_ai.dart';

class JogoDaVelhaIA {
  final GenerativeModel _modelo;

  JogoDaVelhaIA({required String apiKey})
  : _modelo = GenerativeModel(model: 'gemini-1.5-flash-latest', apiKey: apiKey);

  Future <Map<String, int>?> obterJogadaIA(List<List<String>> tabuleiro) async {
    try {
      final prompt = [Content.text(_gerarPrompt(tabuleiro))];
      final resposta = await _modelo.generateContent(prompt);
      return _parseJogadaIA(resposta.text!);      
    } catch (e) {
      return null;
    }
  }

  String _gerarPrompt(List<List<String>> tabuleiro) {
    final tabuleiroJson = jsonEncode(tabuleiro);
    return 'Estamos jogando Jogo da Velha. Eu sou o "X" e você é o "O". '
    'Aqui está o estado atual do tabuleiro em JSON:\n$tabuleiroJson\n. '
    'Por favor, responda com sua jogada com um objeto JSON: {"linha": <linha>, "coluna": <coluna>}, '
    'Não coloque nenhum outro tipo de string na resposta, apenas o objeto JSON para eu converter diretamente no meu ambiente.';    
  }

  Map<String, int>? _parseJogadaIA(String text) {
    try {
      final Map<String, dynamic> dados = jsonDecode(text);
      final linha = dados['linha'];
      final coluna = dados['coluna'];
      if (linha != null && coluna != null && linha >= 0 && linha < 3 && coluna >= 0 && coluna < 3) {
        return {'linha': linha, 'coluna': coluna};
      }
    } catch (e) {
      return null;
    }
    return null;
  }
}