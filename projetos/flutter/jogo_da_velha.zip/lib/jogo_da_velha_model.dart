class JogoDaVelhaModel {
  late List<List<String>> tabuleiro;
  late String jogadorAtual;
  late String vencedor;
  late bool empate;

  JogoDaVelhaModel() {
    reiniciar();
  }

  void reiniciar() {
    tabuleiro = List.generate(3, (_) => List.filled(3, '') );
    /*
      [
        ['0,0'],['0,1'],['0,2'],
        ['1,0'],['1,1'],['1,2'],
        ['2,0'],['2,1'],['2,2'],
      ]
    */
    jogadorAtual = "X";
    vencedor = "";
    empate = false;
  }

  void fazerJogada(int linha, int coluna) {
    if (tabuleiro[linha][coluna] == '') {
      tabuleiro[linha][coluna] = jogadorAtual;
      if (_verificarVencedor(linha, coluna)) {
        vencedor = jogadorAtual;
      } else if (_verificarEmpate()) {
        empate = true;
      } else {
        jogadorAtual = jogadorAtual == 'X' ? 'O' : 'X';        
      }
    }
  }

  bool _verificarVencedor(int linha, int coluna) {
    // Linhas
    if (tabuleiro[linha].every((celula) => celula == jogadorAtual)) {
      return true;
    }
    // Colunas
    if (tabuleiro.every((linha) => linha[coluna] == jogadorAtual)) {
      return true;
    }

    // Diagonais
    // principal
    if (linha == coluna && tabuleiro.every((linha) => linha[tabuleiro.indexOf(linha)] == jogadorAtual)) {
      return true;
    }
    // secundária
    if (linha + coluna == 2 && tabuleiro.every((linha) => linha[2 - tabuleiro.indexOf(linha)] == jogadorAtual)) {
      return true;
    }

    return false;
  }

  bool _verificarEmpate() {
    return tabuleiro.every((linha) => linha.every((celula) => celula != ''));
  }

}