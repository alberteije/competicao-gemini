import 'package:flutter/material.dart';
import 'package:jogo_da_velha/jogo_da_velha_app.dart';

void main() {
  runApp(const JogoDaVelhaApp());
}