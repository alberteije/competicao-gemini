import 'package:flutter/material.dart';
import 'package:jogo_da_velha/jogo_da_velha_pagina.dart';

class JogoDaVelhaApp extends StatelessWidget {
  const JogoDaVelhaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jogo da Velha',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const JogoDaVelhaPagina(apiKey: _apiKey),
    );
  }
}

const String _apiKey = String.fromEnvironment('API_KEY');