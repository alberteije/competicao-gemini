import 'package:flutter/material.dart';
import 'package:jogo_da_velha/jogo_da_velha_ia.dart';
import 'package:jogo_da_velha/jogo_da_velha_model.dart';

class JogoDaVelhaPagina extends StatefulWidget {
  const JogoDaVelhaPagina({super.key, required this.apiKey});

  final String apiKey;

  @override
  State<JogoDaVelhaPagina> createState() => JogoDaVelhaPaginaEstado();
}

class JogoDaVelhaPaginaEstado extends State<JogoDaVelhaPagina> {
  late JogoDaVelhaModel _jogo;
  late JogoDaVelhaIA _ia;
  bool _carregando = false;


  @override
  void initState() {
    super.initState();
    _jogo = JogoDaVelhaModel();
    _ia = JogoDaVelhaIA(apiKey: widget.apiKey);
  }

  void _reiniciarJogo() {
    setState(() {
      _jogo.reiniciar();
    });
  }

  void _aoClicarNaCelula(int linha, int coluna) async {
    if (_jogo.tabuleiro[linha][coluna] != '' || _jogo.vencedor != '' || _jogo.empate || _carregando) {
      return;
    }

    setState(() {
      _jogo.fazerJogada(linha, coluna);
    });

    if (_jogo.vencedor != '' || _jogo.empate) {
      return;
    }

    _carregando = true;
    final jogadaIA = await _ia.obterJogadaIA(_jogo.tabuleiro);
    if (jogadaIA != null) {
      setState(() {
        _jogo.fazerJogada(jogadaIA['linha']!, jogadaIA['coluna']!);
        _carregando = false;
      });
    } else {
      if (!mounted) return null;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erro ao obter jogada da IA')),
      );      
      setState(() {
        _carregando = false;
      });      
    }
  }

  Widget _construirTabuleiro() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (linha) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(3, (coluna) {
            return _construirCelula(linha, coluna);
          }),
        );
      }),
    );
  }

  Widget _construirCelula(int linha, int coluna) {
    return GestureDetector(
      onTap: () => _aoClicarNaCelula(linha, coluna),
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black),
        ),
        child: Center(
          child: Text(
            _jogo.tabuleiro[linha][coluna],
            style: const TextStyle(fontSize: 48),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text("Jogo da Velha"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              _jogo.vencedor.isNotEmpty
              ? 'Vencedor: ${_jogo.vencedor}'
              : _jogo.empate
                ? 'Empate'
                : 'Jogador Atual: ${_jogo.jogadorAtual}',
            ),
            const SizedBox(height: 20,),
            _construirTabuleiro(),
            const SizedBox(height: 20,),
            ElevatedButton(
              onPressed: _reiniciarJogo, 
              child: const Text('Reiniciar Jogo'),
            ),
            if (_carregando) const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}
